//need image

const banners = [
    {
        id: '9471645183',
        imgUrl: require("../assets/Images")
    },
    {
        id: '5656210978',
        imgUrl: require("../assets/Images")
    },
    {
        id: '044416421',
        imgUrl: require("../assets/Images")
    },
    {
        id: '218716591',
        imgUrl: require("../assets/Images")
    },
    {
        id: '218716523',
        imgUrl: require("../assets/Images")
    }
];

export default banners;