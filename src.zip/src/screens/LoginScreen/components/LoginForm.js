import React, { useState, useRef, useEffect } from "react";
import {Field, reduxForm} from 'redux-form';
import { Dimensions, StyleSheet } from 'react-native';

//Colors
import Colors from "../../../utils/Colors";
import CustomText from "../../../components/UI/CustomText";
import {Ionicons} from "@expo/vector-icons";
//Redux - yet installed
import { useDispatch, useSelector } from 'react-redux';
//Action - need implement reducers
import {Login as LoginAction} from "../../../reducers";
//PropTypes check
import PropTypes from "prop-types";
import renderField from "./RenderField";
//Authentication for Touch/Face ID - not added

const { height } = Dimensions.get('window');

const Login = (props) => {
    return (

    );
};


const styles = StyleSheet.create({
    group: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        marginVertical: 10
    },
    header: {
        marginTop: height * 0.2,
        marginBottom: 10,
        marginHorizontal: 20
    },
    title: {
        color: Colors.light_green,
        fontSize: 40,
        letterSpacing: 5,
        fontFamily: 'Roboto-Bold',
        textAlign: 'center'
    },
    text: {
        color: '#fff',
    },
    signIn: {
        width: '100%',
        height: 50,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        backgroundColor: Colors.lighter_green,
    },
    textSign: {
        fontSize: 15,
        color: '#fff',
        fontFamily: 'Roboto-Medium'
    },
    textSignSmall: {
        color: Colors.lighter_green,
        textAlign: 'center'
    },
    center: {
        alignItems: 'center'
    },
    circleImage: {
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 
    }
});