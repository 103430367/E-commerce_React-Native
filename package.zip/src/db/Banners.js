

const banners = [
    {
        id: '9471645183',
        imgUrl: require("../assets/Images/banner1.jpg")
    },
    {
        id: '5656210978',
        imgUrl: require("../assets/Images/banner6.jpg")
    },
    {
        id: '044416421',
        imgUrl: require("../assets/Images/banner3.jpg")
    },
    {
        id: '218716591',
        imgUrl: require("../assets/Images/banner5.jpg")
    },
    {
        id: '218716523',
        imgUrl: require("../assets/Images/banner4.jpg")
    }
];

export default banners;