export default comments = [
    {
        id: 1,
        username: "Lionel Nguyen",
        content: "Sản phẩm đẹp, giao hàng nhanh"
    },
    {
        id: 2,
        username: "Kim Tinh",
        content: "Mình mua vòng này mang được hơn 1 tháng, vòng rất sáng chất lượng tốt. Cảm ơn shop nhiều."
    },
    {
        id: 3,
        username: "Nam Thọ",
        content: "Vòng đẹp, màu sắc như hình, chất lượng thì để mang một thời gian nữa rồi vào đánh giá tiếp ^^"
    },
    {
        id: 4,
        username: "Nguyên Hưng",
        content: "Hàng đẹp xịn xò, cho 5 sao."
    },
    {
        id: 5,
        username: "Hà Bò",
        content: "Vừa đặt ở đây, chủ shop thân thiện, sản phẩm đẹp"
    },
    {
        id: 6,
        username: "Khiêm",
        content: "Vòng đẹp, chất lượng đúng như quảng cáo"
    }
]